# Backend dev

Steps to run this project:

1. Run `npm i` command or Run `yarn` 
2. Setup database settings inside `ormconfig.json` file
3. Run `npm start` command or `yarn dev` command
4. for testing Run `yarn jest` or `yarn test`
